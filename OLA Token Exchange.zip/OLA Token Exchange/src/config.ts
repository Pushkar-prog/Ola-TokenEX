import { ICollectionType, IConfig } from "./lib/app/types";

const CONFIG: IConfig = {
    coinDenom: "uandr",
    name: "OLA Token Exchange",
    chainId: "galileo-4",
    createdDate: "2025-01-03T09:34:53.102Z",
    modifiedDate: "2025-01-03T09:34:53.102Z",
    id: "andromeda",
    collections: [
        {
            exchange: "andr19mj2mfrzd5zqvasv3yyx27t3vyry7j7gc8jpf2ppfl2p803kjarsvpntv7",
            cw20: "andr19ktxejt2e5muq288fp2m2jfyuf7s5dvqkhkajw4tsma8pyn0f3rqncua0y",
            name: "OLA Token Exchange",
            type: ICollectionType.EXCHANGE,
            id: "exchange",
        }
    ],
};

export default CONFIG;
