import { useAppStore } from "@/zustand/app";

const useApp = () => useAppStore();
export default useApp;

