import { DefaultApp } from "@/modules/default";
import React, { FC } from "react"


interface Props {
}

const Page = async (props: Props) => {
    const { } = props;
    return (
        <DefaultApp />
    )
}

export default Page